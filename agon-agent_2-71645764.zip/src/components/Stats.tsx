import { motion } from "framer-motion";

const STATS = [
  { v: "120+", l: "Projects Delivered" },
  { v: "10+", l: "Years of Experience" },
  { v: "4.4★", l: "Client Rating" },
  { v: "100%", l: "Commitment to Quality" },
];

export default function Stats() {
  return (
    <section className="bg-amber text-ink">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-2 lg:grid-cols-4 gap-8">
        {STATS.map((s, i) => (
          <motion.div
            key={s.l}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="text-center lg:text-left"
          >
            <div className="font-display font-extrabold text-4xl sm:text-5xl">{s.v}</div>
            <div className="text-sm font-semibold uppercase tracking-wider mt-1 opacity-80">
              {s.l}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

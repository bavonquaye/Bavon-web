import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, MapPin, Clock, Send, CheckCircle2 } from "lucide-react";
import { COMPANY } from "../lib/data";

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", type: "Residential Construction", msg: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="contact" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-5 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -25 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <span className="text-amber text-xs font-bold uppercase tracking-[0.3em]">
              Get In Touch
            </span>
            <h2 className="font-display font-extrabold uppercase text-4xl sm:text-5xl mt-3">
              Start Your Build Today
            </h2>
            <p className="mt-4 text-paper/60">
              Call us or send a message — we’ll visit your site, discuss your
              vision and give you an honest, detailed quote.
            </p>

            <div className="mt-9 space-y-5">
              <a
                href={COMPANY.phoneHref}
                className="flex items-center gap-4 bg-ink-3 border border-white/8 hover:border-amber/50 rounded-xl p-5 transition-colors group"
              >
                <div className="w-12 h-12 rounded-lg bg-amber/10 border border-amber/25 flex items-center justify-center text-amber group-hover:bg-amber group-hover:text-ink transition-colors shrink-0">
                  <Phone size={20} />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-paper/50 font-semibold">Call / WhatsApp</div>
                  <div className="font-bold text-lg text-paper">{COMPANY.phone}</div>
                </div>
              </a>

              <a
                href={`https://www.google.com/maps?q=${COMPANY.lat},${COMPANY.lng}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-4 bg-ink-3 border border-white/8 hover:border-amber/50 rounded-xl p-5 transition-colors group"
              >
                <div className="w-12 h-12 rounded-lg bg-amber/10 border border-amber/25 flex items-center justify-center text-amber group-hover:bg-amber group-hover:text-ink transition-colors shrink-0">
                  <MapPin size={20} />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-paper/50 font-semibold">Visit Us</div>
                  <div className="font-bold text-paper">{COMPANY.address}</div>
                </div>
              </a>

              <div className="flex items-center gap-4 bg-ink-3 border border-white/8 rounded-xl p-5">
                <div className="w-12 h-12 rounded-lg bg-amber/10 border border-amber/25 flex items-center justify-center text-amber shrink-0">
                  <Clock size={20} />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-widest text-paper/50 font-semibold">Working Hours</div>
                  <div className="font-bold text-paper">Mon – Sat: 7:00 AM – 6:00 PM</div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 25 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-3"
          >
            <div className="bg-ink-2 border border-white/8 rounded-2xl p-7 sm:p-10 h-full">
              {sent ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-16">
                  <div className="w-16 h-16 rounded-full bg-amber/15 border border-amber/40 flex items-center justify-center text-amber mb-5">
                    <CheckCircle2 size={30} />
                  </div>
                  <h3 className="font-display font-bold uppercase text-3xl">Message Received!</h3>
                  <p className="mt-3 text-paper/60 max-w-sm">
                    Thank you, {form.name || "friend"}. Our team will reach you
                    shortly. For urgent enquiries, call{" "}
                    <a href={COMPANY.phoneHref} className="text-amber font-semibold">
                      {COMPANY.phone}
                    </a>.
                  </p>
                  <button
                    onClick={() => setSent(false)}
                    className="mt-7 text-sm font-bold uppercase tracking-wider text-amber hover:text-amber-2"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={submit} className="space-y-5">
                  <h3 className="font-display font-bold uppercase text-2xl tracking-wide">
                    Request a Free Quote
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label htmlFor="name" className="block text-xs font-bold uppercase tracking-widest text-paper/50 mb-2">
                        Full Name
                      </label>
                      <input
                        id="name"
                        required
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        placeholder="Kofi Mensah"
                        className="w-full bg-ink border border-white/10 rounded-lg px-4 py-3.5 text-paper placeholder:text-paper/25 focus:outline-none focus:border-amber transition-colors"
                      />
                    </div>
                    <div>
                      <label htmlFor="phone" className="block text-xs font-bold uppercase tracking-widest text-paper/50 mb-2">
                        Phone Number
                      </label>
                      <input
                        id="phone"
                        required
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        placeholder="+233 XX XXX XXXX"
                        className="w-full bg-ink border border-white/10 rounded-lg px-4 py-3.5 text-paper placeholder:text-paper/25 focus:outline-none focus:border-amber transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="type" className="block text-xs font-bold uppercase tracking-widest text-paper/50 mb-2">
                      Project Type
                    </label>
                    <select
                      id="type"
                      value={form.type}
                      onChange={(e) => setForm({ ...form, type: e.target.value })}
                      className="w-full bg-ink border border-white/10 rounded-lg px-4 py-3.5 text-paper focus:outline-none focus:border-amber transition-colors"
                    >
                      <option>Residential Construction</option>
                      <option>Commercial Building</option>
                      <option>Real Estate Development</option>
                      <option>Civil & Structural Works</option>
                      <option>Renovation & Remodelling</option>
                      <option>Project Management</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="msg" className="block text-xs font-bold uppercase tracking-widest text-paper/50 mb-2">
                      Project Details
                    </label>
                    <textarea
                      id="msg"
                      required
                      rows={5}
                      value={form.msg}
                      onChange={(e) => setForm({ ...form, msg: e.target.value })}
                      placeholder="Tell us about your project — location, size, timeline..."
                      className="w-full bg-ink border border-white/10 rounded-lg px-4 py-3.5 text-paper placeholder:text-paper/25 focus:outline-none focus:border-amber transition-colors resize-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-2 bg-amber hover:bg-amber-2 text-ink font-bold uppercase tracking-wider text-sm px-7 py-4 rounded-lg transition-colors"
                  >
                    <Send size={16} />
                    Send Enquiry
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-14 rounded-2xl overflow-hidden border border-white/10"
        >
          <iframe
            title="Anchor-Bolt Company Limited location — Apramado Market, Takoradi"
            src={`https://maps.google.com/maps?q=${COMPANY.lat},${COMPANY.lng}&z=15&output=embed`}
            className="w-full h-[380px] grayscale-[35%] contrast-105"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </motion.div>
      </div>
    </section>
  );
}

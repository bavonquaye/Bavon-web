import { motion } from "framer-motion";
import {
  Home,
  Building2,
  Landmark,
  HardHat,
  Hammer,
  ClipboardList,
  ArrowUpRight,
} from "lucide-react";
import { SERVICES } from "../lib/data";

const ICONS: Record<string, React.ElementType> = {
  home: Home,
  building: Building2,
  landmark: Landmark,
  hardhat: HardHat,
  hammer: Hammer,
  clipboard: ClipboardList,
};

export default function Services() {
  return (
    <section id="services" className="py-24 bg-ink-2 relative">
      <div className="absolute top-0 inset-x-0 h-1.5 hazard-stripe opacity-60" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-14">
          <span className="text-amber text-xs font-bold uppercase tracking-[0.3em]">
            What We Do
          </span>
          <h2 className="font-display font-extrabold uppercase text-4xl sm:text-5xl mt-3">
            Construction Services
          </h2>
          <p className="mt-4 text-paper/60">
            One contractor, every trade. We deliver complete building solutions
            for private clients, businesses and developers.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((s, i) => {
            const Icon = ICONS[s.icon];
            return (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 25 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: (i % 3) * 0.1 }}
                className="group bg-ink-3 border border-white/5 rounded-xl p-7 hover:border-amber/50 hover:-translate-y-1 transition-all duration-300"
              >
                <div className="flex items-start justify-between">
                  <div className="w-13 h-13 p-3 rounded-lg bg-amber/10 border border-amber/25 text-amber group-hover:bg-amber group-hover:text-ink transition-colors">
                    <Icon size="100%" strokeWidth={1.8} />
                  </div>
                  <ArrowUpRight
                    size={20}
                    className="text-paper/20 group-hover:text-amber transition-colors"
                  />
                </div>
                <h3 className="font-display font-bold uppercase text-2xl mt-5 tracking-wide">
                  {s.title}
                </h3>
                <p className="mt-3 text-sm text-paper/60 leading-relaxed">{s.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { TESTIMONIALS, COMPANY } from "../lib/data";

export default function Testimonials() {
  return (
    <section className="py-24 bg-ink-2 grid-texture">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-amber text-xs font-bold uppercase tracking-[0.3em]">
            Client Feedback
          </span>
          <h2 className="font-display font-extrabold uppercase text-4xl sm:text-5xl mt-3">
            Trusted in Takoradi
          </h2>
          <div className="mt-4 inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2">
            <div className="flex gap-0.5">
              {[1, 2, 3, 4].map((n) => (
                <Star key={n} size={15} className="text-amber fill-amber" />
              ))}
              <Star size={15} className="text-amber fill-amber opacity-40" />
            </div>
            <span className="text-sm text-paper/70 font-medium">
              {COMPANY.rating} / 5 average rating
            </span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <motion.blockquote
              key={t.name}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-ink-3 border border-white/5 rounded-xl p-7 flex flex-col"
            >
              <Quote size={28} className="text-amber/50" />
              <p className="mt-4 text-paper/80 leading-relaxed flex-1">“{t.text}”</p>
              <footer className="mt-6 pt-5 border-t border-white/8">
                <div className="flex gap-0.5 mb-2">
                  {Array.from({ length: t.stars }).map((_, n) => (
                    <Star key={n} size={13} className="text-amber fill-amber" />
                  ))}
                </div>
                <div className="font-bold text-paper">{t.name}</div>
                <div className="text-xs text-paper/50 uppercase tracking-wider mt-0.5">
                  {t.role}
                </div>
              </footer>
            </motion.blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}

import { Phone, MapPin, Star } from "lucide-react";
import Logo from "./Logo";
import { COMPANY } from "../lib/data";

export default function Footer() {
  return (
    <footer className="bg-ink-2 border-t border-white/5">
      <div className="h-1.5 hazard-stripe" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 grid md:grid-cols-3 gap-10">
        <div>
          <Logo />
          <p className="mt-5 text-sm text-paper/55 leading-relaxed max-w-xs">
            Construction & real-estate building company serving Takoradi and
            the Western Region of Ghana. Anchored in quality, bolted by trust.
          </p>
          <div className="mt-4 inline-flex items-center gap-1.5 text-sm text-paper/70">
            <Star size={14} className="text-amber fill-amber" />
            {COMPANY.rating} rating · {COMPANY.reviews} Google reviews
          </div>
        </div>

        <div>
          <h4 className="font-display font-bold uppercase tracking-wider text-lg mb-4">
            Quick Links
          </h4>
          <ul className="space-y-2.5 text-sm">
            {[
              ["About Us", "#about"],
              ["Services", "#services"],
              ["Projects", "#projects"],
              ["Why Choose Us", "#why-us"],
              ["Contact", "#contact"],
            ].map(([label, href]) => (
              <li key={href}>
                <a href={href} className="text-paper/55 hover:text-amber transition-colors">
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display font-bold uppercase tracking-wider text-lg mb-4">
            Contact
          </h4>
          <ul className="space-y-3.5 text-sm">
            <li>
              <a href={COMPANY.phoneHref} className="flex items-center gap-3 text-paper/55 hover:text-amber transition-colors">
                <Phone size={16} className="text-amber shrink-0" />
                {COMPANY.phone}
              </a>
            </li>
            <li>
              <a
                href={`https://www.google.com/maps?q=${COMPANY.lat},${COMPANY.lng}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-start gap-3 text-paper/55 hover:text-amber transition-colors"
              >
                <MapPin size={16} className="text-amber shrink-0 mt-0.5" />
                {COMPANY.address}
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-paper/40">
          <span>
            © {new Date().getFullYear()} {COMPANY.name}. All rights reserved.
          </span>
          <span>Takoradi · Western Region · Ghana</span>
        </div>
      </div>
    </footer>
  );
}

import { motion } from "framer-motion";
import { ArrowRight, MapPin, Star, Phone } from "lucide-react";
import { COMPANY } from "../lib/data";

export default function Hero() {
  return (
    <section className="relative min-h-[100svh] flex items-center">
      <div className="absolute inset-0">
        <img
          src="/images/hero.jpg"
          alt="Construction site in Takoradi"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/60" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-28 pb-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="max-w-3xl"
        >
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <span className="inline-flex items-center gap-1.5 bg-amber/15 border border-amber/40 text-amber text-xs font-semibold uppercase tracking-widest px-3 py-1.5 rounded-full">
              <MapPin size={12} /> Takoradi · Western Region · Ghana
            </span>
            <span className="inline-flex items-center gap-1.5 bg-white/5 border border-white/15 text-paper/90 text-xs font-semibold px-3 py-1.5 rounded-full">
              <Star size={12} className="text-amber fill-amber" />
              {COMPANY.rating} rated · {COMPANY.reviews} reviews
            </span>
          </div>

          <h1 className="font-display font-extrabold uppercase leading-[0.95] text-5xl sm:text-6xl lg:text-8xl tracking-tight">
            We Build Ghana’s
            <span className="block text-amber">Foundations.</span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-paper/75 max-w-xl leading-relaxed">
            Anchor-Bolt Company Limited is a trusted construction and
            real-estate building firm in Takoradi — delivering residential,
            commercial and civil projects with precision, integrity and
            strength that lasts.
          </p>

          <div className="mt-9 flex flex-wrap gap-4">
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 bg-amber text-ink font-bold px-7 py-4 rounded-md hover:bg-amber-2 transition-colors text-sm uppercase tracking-wider"
            >
              Request a Quote
              <ArrowRight size={17} className="group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href={COMPANY.phoneHref}
              className="inline-flex items-center gap-2 border-2 border-paper/25 hover:border-amber text-paper hover:text-amber font-bold px-7 py-4 rounded-md transition-colors text-sm uppercase tracking-wider"
            >
              <Phone size={17} />
              Call Us Now
            </a>
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-0 inset-x-0 h-3 hazard-stripe" />
    </section>
  );
}

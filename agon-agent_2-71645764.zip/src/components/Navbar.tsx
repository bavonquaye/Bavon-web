import { useEffect, useState } from "react";
import { Menu, X, Phone } from "lucide-react";
import Logo from "./Logo";
import { COMPANY } from "../lib/data";

const LINKS = [
  { href: "#about", label: "About" },
  { href: "#services", label: "Services" },
  { href: "#projects", label: "Projects" },
  { href: "#why-us", label: "Why Us" },
  { href: "#contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    fn();
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <header
      id="top"
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-ink/95 backdrop-blur-md border-b border-amber/20 shadow-lg shadow-black/30"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 py-3">
          <Logo />
          <nav className="hidden lg:flex items-center gap-8">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm font-medium uppercase tracking-widest text-paper/70 hover:text-amber transition-colors"
              >
                {l.label}
              </a>
            ))}
            <a
              href={COMPANY.phoneHref}
              className="flex items-center gap-2 bg-amber text-ink font-bold text-sm px-5 py-2.5 rounded-md hover:bg-amber-2 transition-colors"
            >
              <Phone size={15} />
              {COMPANY.phone}
            </a>
          </nav>
          <button
            onClick={() => setOpen(!open)}
            className="lg:hidden text-paper p-2"
            aria-label="Toggle menu"
          >
            {open ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>
      </div>
      {open && (
        <div className="lg:hidden bg-ink-2 border-t border-amber/20">
          <nav className="px-6 py-4 flex flex-col gap-1">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="py-3 text-paper/80 hover:text-amber font-medium uppercase tracking-widest text-sm border-b border-white/5"
              >
                {l.label}
              </a>
            ))}
            <a
              href={COMPANY.phoneHref}
              className="mt-3 flex items-center justify-center gap-2 bg-amber text-ink font-bold px-5 py-3 rounded-md"
            >
              <Phone size={16} />
              {COMPANY.phone}
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import { PROJECTS } from "../lib/data";

export default function Projects() {
  return (
    <section id="projects" className="py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-14">
          <div className="max-w-2xl">
            <span className="text-amber text-xs font-bold uppercase tracking-[0.3em]">
              Our Work
            </span>
            <h2 className="font-display font-extrabold uppercase text-4xl sm:text-5xl mt-3">
              Recent Projects
            </h2>
          </div>
          <p className="text-paper/60 max-w-sm text-sm">
            A selection of the residential, commercial and civil works we’ve
            delivered across the Western Region.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          {PROJECTS.map((p, i) => (
            <motion.figure
              key={p.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: (i % 2) * 0.12 }}
              className="group relative rounded-xl overflow-hidden h-80 cursor-pointer"
            >
              <img
                src={p.img}
                alt={p.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" />
              <figcaption className="absolute bottom-0 inset-x-0 p-6">
                <span className="inline-block bg-amber text-ink text-[11px] font-bold uppercase tracking-widest px-2.5 py-1 rounded">
                  {p.tag}
                </span>
                <h3 className="font-display font-bold uppercase text-2xl mt-3 tracking-wide">
                  {p.title}
                </h3>
                <p className="flex items-center gap-1.5 text-sm text-paper/70 mt-1">
                  <MapPin size={13} className="text-amber" /> {p.place}
                </p>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}

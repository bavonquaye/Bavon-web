import { motion } from "framer-motion";
import { VALUES } from "../lib/data";

export default function Values() {
  return (
    <section id="why-us" className="py-24 bg-paper text-ink relative">
      <div className="absolute top-0 inset-x-0 h-1.5 hazard-stripe" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mb-14">
          <span className="text-amber text-xs font-bold uppercase tracking-[0.3em]">
            Why Anchor-Bolt
          </span>
          <h2 className="font-display font-extrabold uppercase text-4xl sm:text-5xl mt-3">
            Built Different. Built Right.
          </h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {VALUES.map((v, i) => (
            <motion.div
              key={v.n}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="border-t-4 border-amber pt-5"
            >
              <span className="font-display font-extrabold text-5xl text-ink/10">
                {v.n}
              </span>
              <h3 className="font-display font-bold uppercase text-2xl mt-2 tracking-wide">
                {v.t}
              </h3>
              <p className="mt-3 text-sm text-ink/65 leading-relaxed">{v.d}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

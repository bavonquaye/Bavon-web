import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

const POINTS = [
  "Registered Ghanaian construction & real-estate building company",
  "Full-service: design coordination, build, finish & handover",
  "Skilled local workforce and vetted material suppliers",
  "Serving Takoradi, Sekondi and the wider Western Region",
];

export default function About() {
  return (
    <section id="about" className="relative py-24 grid-texture">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid lg:grid-cols-2 gap-14 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative"
        >
          <div className="absolute -top-4 -left-4 w-full h-full border-2 border-amber/40 rounded-xl" />
          <img
            src="/images/about.jpg"
            alt="Anchor-Bolt site engineers at work"
            className="relative rounded-xl w-full h-[420px] object-cover shadow-2xl shadow-black/50"
          />
          <div className="absolute -bottom-6 -right-4 sm:right-6 bg-amber text-ink rounded-lg px-6 py-4 shadow-xl">
            <div className="font-display font-extrabold text-3xl leading-none">EST. TAKORADI</div>
            <div className="text-xs font-bold uppercase tracking-widest mt-1">Apramado Market Area</div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-amber text-xs font-bold uppercase tracking-[0.3em]">
            Who We Are
          </span>
          <h2 className="font-display font-extrabold uppercase text-4xl sm:text-5xl mt-3 leading-tight">
            Strength You Can <span className="text-amber">Anchor</span> Your Future On
          </h2>
          <p className="mt-5 text-paper/70 leading-relaxed">
            Based at Apramado Market in the heart of Takoradi, Anchor-Bolt
            Company Limited builds homes, commercial properties and civil
            infrastructure across Ghana’s Western Region. Our name is our
            promise — every structure we raise is anchored in sound
            engineering and bolted together with craftsmanship.
          </p>
          <p className="mt-4 text-paper/70 leading-relaxed">
            From a single-family home to a multi-storey commercial block, we
            manage every stage of your project so you can build with
            confidence.
          </p>
          <ul className="mt-7 space-y-3">
            {POINTS.map((p) => (
              <li key={p} className="flex items-start gap-3">
                <CheckCircle2 size={20} className="text-amber shrink-0 mt-0.5" />
                <span className="text-paper/85">{p}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </section>
  );
}

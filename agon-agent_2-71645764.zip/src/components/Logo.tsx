export default function Logo({ light = false }: { light?: boolean }) {
  return (
    <a href="#top" className="flex items-center gap-3 group">
      <div className="w-10 h-10 rounded-lg bg-amber flex items-center justify-center shrink-0">
        <svg viewBox="0 0 64 64" className="w-6 h-6">
          <path
            d="M32 8 L48 22 L42 22 L42 50 L36 50 L36 30 L28 30 L28 50 L22 50 L22 22 L16 22 Z"
            fill="#171412"
          />
          <rect x="18" y="52" width="28" height="5" fill="#171412" />
        </svg>
      </div>
      <div className="leading-none">
        <span
          className={`font-display font-800 text-xl tracking-wide uppercase font-extrabold ${
            light ? "text-ink" : "text-paper"
          }`}
        >
          Anchor-Bolt
        </span>
        <span className="block text-[10px] tracking-[0.3em] uppercase text-amber font-semibold mt-1">
          Company Limited
        </span>
      </div>
    </a>
  );
}

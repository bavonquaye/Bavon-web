export const COMPANY = {
  name: "Anchor-Bolt Company Limited",
  shortName: "Anchor-Bolt",
  address: "Apramado Market, Takoradi, Ghana",
  phone: "+233 24 457 9689",
  phoneHref: "tel:+233244579689",
  region: "Western Region",
  country: "Ghana",
  lat: 4.9020818,
  lng: -1.7831724,
  rating: 4.4,
  reviews: 5,
  categories: ["Construction companies", "Real Estate Builders"],
};

export const SERVICES = [
  {
    title: "Residential Construction",
    desc: "Complete home building — from foundation to finishing. Family houses, apartment blocks and estate developments built to last in the Western Region climate.",
    icon: "home",
  },
  {
    title: "Commercial Buildings",
    desc: "Shops, offices, warehouses and market structures engineered for durability and delivered on schedule for Takoradi's growing business community.",
    icon: "building",
  },
  {
    title: "Real Estate Development",
    desc: "End-to-end estate builds: land preparation, architectural coordination, phased construction and handover of move-in-ready properties.",
    icon: "landmark",
  },
  {
    title: "Civil & Structural Works",
    desc: "Reinforced concrete, structural steel, drainage, retaining walls and groundworks executed to engineering specification.",
    icon: "hardhat",
  },
  {
    title: "Renovation & Remodelling",
    desc: "Modernise, extend or repurpose existing structures. We assess, plan and rebuild with minimal disruption to your operations.",
    icon: "hammer",
  },
  {
    title: "Project Management",
    desc: "Full supervision of your build — budgeting, procurement, labour management and quality assurance from breaking ground to final inspection.",
    icon: "clipboard",
  },
];

export const PROJECTS = [
  {
    img: "/images/project1.jpg",
    tag: "Residential",
    title: "Modern Family Residences",
    place: "Takoradi, Western Region",
  },
  {
    img: "/images/project2.jpg",
    tag: "Commercial",
    title: "Multi-Storey Commercial Block",
    place: "Sekondi-Takoradi",
  },
  {
    img: "/images/project3.jpg",
    tag: "Civil Works",
    title: "Access Road & Groundworks",
    place: "Apramado, Takoradi",
  },
  {
    img: "/images/project4.jpg",
    tag: "Renovation",
    title: "Interior Fit-Out & Remodel",
    place: "Western Region",
  },
];

export const VALUES = [
  { n: "01", t: "Built on Integrity", d: "Transparent quotes, honest timelines, no surprises. Your budget is respected from day one." },
  { n: "02", t: "Engineered to Last", d: "Quality materials and proven methods suited to coastal Ghana — every anchor, every bolt, every beam." },
  { n: "03", t: "Local Expertise", d: "Rooted in Takoradi. We know the land, the suppliers, the regulations and the people." },
  { n: "04", t: "Delivered on Time", d: "Disciplined project management keeps your build moving and your handover date firm." },
];

export const TESTIMONIALS = [
  {
    name: "Kwame A.",
    role: "Homeowner, Takoradi",
    text: "Anchor-Bolt handled my house project from foundation to roofing. Solid workmanship and they kept me informed at every stage.",
    stars: 5,
  },
  {
    name: "Efua M.",
    role: "Shop Owner, Apramado Market",
    text: "They rebuilt my store structure quickly and professionally. Fair pricing and the finishing was excellent.",
    stars: 5,
  },
  {
    name: "Joseph B.",
    role: "Property Developer",
    text: "Reliable contractor for our estate phase. Good site discipline and quality control. I would engage them again.",
    stars: 4,
  },
];
